
public class FilaVaziaException extends RuntimeException {
	    public FilaVaziaException(String err){
	       super(err); 
	    }   
}